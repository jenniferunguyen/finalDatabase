create view MyPets as
select `S`.`ShelterID`      AS `ShelterID`,
       `S`.`Phone`          AS `Phone`,
       `S`.`Email`          AS `Email`,
       `P`.`PetID`          AS `PetID`,
       `P`.`Name`           AS `Name`,
       `P`.`Phase`          AS `Phase`,
       `P`.`DateOfBirth`    AS `DateOfBirth`,
       `P`.`Type`           AS `Type`,
       `P`.`HealthConcerns` AS `HealthConcerns`,
       `E`.`EmployeeID`     AS `EmployeeID`
from ((((`Final`.`Shelters` `S` join `Final`.`PetToShelter` `PTS` on ((`S`.`ShelterID` = `PTS`.`ShelterID`))) join `Final`.`Pets` `P` on ((`P`.`PetID` = `PTS`.`PetID`))) join `Final`.`EmployeeToShelter` `ETS` on ((`PTS`.`ShelterID` = `ETS`.`ShelterID`)))
         join `Final`.`Employees` `E` on ((`E`.`EmployeeID` = `ETS`.`EmployeeID`)))
where (`P`.`Deleted` = 0);

