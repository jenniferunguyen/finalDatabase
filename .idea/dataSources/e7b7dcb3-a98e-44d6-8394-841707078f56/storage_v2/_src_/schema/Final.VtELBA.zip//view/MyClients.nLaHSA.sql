create view MyClients as
select `C`.`ClientID`    AS `ClientID`,
       `C`.`FirstName`   AS `cFirstName`,
       `C`.`LastName`    AS `cLastName`,
       `C`.`DateOfBirth` AS `DateOfBirth`,
       `C`.`Phone`       AS `cPhone`,
       `C`.`Email`       AS `cEmail`,
       `C`.`Address`     AS `Address`,
       `C`.`City`        AS `City`,
       `C`.`State`       AS `State`,
       `C`.`Zip`         AS `Zip`,
       `C`.`Occupation`  AS `Occupation`,
       `C`.`Preference`  AS `Preference`,
       `C`.`Phase`       AS `Phase`,
       `C`.`Status`      AS `Status`,
       `C`.`StatusDate`  AS `StatusDate`,
       `E`.`EmployeeID`  AS `EmployeeID`,
       `E`.`FirstName`   AS `eFirstName`,
       `E`.`LastName`    AS `eLastName`,
       `E`.`Email`       AS `eEmail`,
       `E`.`Phone`       AS `ePhone`
from ((`Final`.`Clients` `C` join `Final`.`ClientToEmployee` `CTE` on ((`C`.`ClientID` = `CTE`.`ClientID`)))
         join `Final`.`Employees` `E` on ((`E`.`EmployeeID` = `CTE`.`EmployeeID`)))
where (`C`.`Deleted` = 0);

